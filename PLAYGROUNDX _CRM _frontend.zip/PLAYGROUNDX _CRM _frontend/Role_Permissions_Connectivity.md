# PlayGroundX CRM - Roles, Workflows & Connectivity

Is software mein total **7 roles** hain. Ye saare roles ek well-defined hierarchy aur workflow mein connected hain taaki operations smoothly chal sakein.

---

## 👥 The 7 Roles & How They Work

### 1. ADMIN (Super Admin)
*   **Kaam:** Ye software ka ultimate owner hai.
*   **Access:** Full system access.
*   **Work:** Naye users aur roles create karna, AI ke rules set karna, naye departments banana, global revenue aur campaigns manage karna. Admin sabhi departments ka overview dekh sakta hai.

### 2. EXECUTIVE (CEO)
*   **Kaam:** Business growth aur revenue ko monitor karna.
*   **Access:** High-level Analytics & Read-only.
*   **Work:** CEO daily lead management ya chats nahi karta. Usko bas "Executive Dashboard" dikhega jisme: Total Revenue, New Creators/Fans, Churn Rate aur AI Metrics honge.

### 3. MANAGER
*   **Kaam:** Multiple departments ya ek bade department ka head (Example: Head of Creator Success).
*   **Access:** Apne departments ka full view.
*   **Work:** Agents ki performance monitor karna, SLA (Service Level Agreements) check karna, aur queues assign karna. Agar koi issue bada hai, toh usko solve karna.

### 4. SUPERVISOR
*   **Kaam:** Ek specific language ya niche department ko manage karna (Example: Spanish Creator Supervisor).
*   **Access:** Sirf apne team ke agents aur unki leads ka access.
*   **Work:** Apne agents ki live queues dekhna. Agar kisi agent se lead handle nahi ho rahi ya customer gusse mein hai, toh us chat/call ko apne paas escalate (transfer) kar lena.

### 5. AGENT
*   **Kaam:** Frontline operator jo actually users se baat karega.
*   **Access:** Sirf apni assign ki hui leads aur tasks.
*   **Work:** "My Leads" dashboard me kaam karna. Calls lena, WhatsApp/Emails reply karna, KYC verify karna, aur appointments schedule karna. Ek agent dusre agent ki chat nahi dekh sakta jab tak lead transfer na ki jaye.

### 6. VIEWER
*   **Kaam:** External auditors ya consultants.
*   **Access:** Read-only access to specific reports.
*   **Work:** Sirf activities aur analytics dekh sakte hain. Inke paas edit ya delete karne ka koi permission nahi hota.

### 7. AI SYSTEM (Virtual Role)
*   **Kaam:** 24/7 Virtual Success Manager.
*   **Access:** Sabhi leads aur unki progress.
*   **Work:** Lead aate hi usko welcome message bhejna. Agar user next step (jaise KYC ya deposit) pe nahi jaata, toh auto-reminders bhejna. AI automatically leads ko score karta hai aur 'Hot Leads' ko Agents ke paas bhejta hai.

---

## 🔗 Role Connectivity & Workflow (Kaun Kisse Kaise Connected Hai)

Sabhi roles ek doosre se "Routing & Escalation System" ke through connected hain. Ye aise flow karta hai:

### **Level 1: AI to Agent (The Handoff)**
1. **Lead Aati Hai:** AI sabse pehle lead se baat shuru karta hai (Automated onboarding).
2. **Escalation Trigger:** Agar user bolta hai *"Call me"*, *"Payment Failed"*, ya wo ek bahut bada Influencer (VIP) hai, toh AI khud chat handle karna band karta hai.
3. **Queue Creation:** AI ek "Opportunity" banata hai aur usko Agent Queue me bhej deta hai.
4. **Agent Action:** Khali betha hua Agent us lead ko "Claim" karta hai aur aage ka kaam sambhalta hai.

### **Level 2: Agent to Supervisor (The Escalation)**
1. **Agent Stuck:** Agar Agent user ko convert nahi kar pa raha ya user ko koi complex issue hai.
2. **Transfer:** Agent apne system se ek click karta hai aur lead ko apne **Supervisor** ko transfer kar deta hai.
3. **Supervisor Action:** Supervisor us lead ko apne panel me dekhta hai aur directly call/chat karke problem solve karta hai.

### **Level 3: Manager & Admin (The Oversight)**
1. **Manager Monitor:** Manager ek screen par apne saare Supervisors aur Agents ka live dashboard dekhta hai. Usko pata hota hai ki Spanish team kaisa perform kar rahi hai aur English team kaisa.
2. **Admin Control:** Admin backend se yeh sab rules, departments, aur AI ke triggers set karta hai jiske base par Manager aur Supervisor apni teams chalate hain.
3. **Executive Dashboard:** Saari teams se generate hua revenue aur leads ka data seedha upar CEO (Executive) ke dashboard par real-time me update hota rehta hai.

### Summary of the Flow:
**System/AI (Onboarding) ➡️ Agent (Operation/Sales) ➡️ Supervisor (Escalation) ➡️ Manager (Monitoring) ➡️ Admin (Configuration) ➡️ Executive (Analytics View)**
